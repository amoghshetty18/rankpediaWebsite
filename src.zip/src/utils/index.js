import { breakpoints, device } from "./breakpoints";

export { device, breakpoints };
