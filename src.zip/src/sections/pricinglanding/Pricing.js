import React from "react";

const Pricing = () => {
  return (


<div>
    <div className="pb-5 pb-md-11 pb-lg-19">
    <div className="container">
      <div className="row justify-content-center">

      <form action="/action_page.php" className="select-form-pricelanding">
  <select name="cars" className="border" id="pricelanding-select-cars">
    <option value="volvo">You have selected Class 8</option>
    <option value="saab">You have selected Class 9</option>
    <option value="opel">You have selected Class 10</option>
  </select>
</form>


        </div>
        </div>
        </div>

    <div className="pb-5 pb-md-11 pb-lg-19">
      <div className="container">
        <div className="row justify-content-center">
          {/* Single Table */}
          <div className="col-xl-4 col-lg-5 col-md-6 col-sm-8">
            <div
              className="border rounded-10 text-center pb-13 gr-hover-2 mb-9"
              data-aos="fade-up"
              data-aos-duration={300}
              data-aos-once="true"
            >
              <div className="pricelandingfirst-section">
              <p className="price-tp1r mb-5">Basic</p>
              <h2 className="price-fntdsfr mb-1">INR XXX
              <span className="price-landing-mntds mb-2">/month</span></h2>
              <h2 className="price-fntdsfr mb-1">INR XXX 
              <span className="price-landing-mntds mb-2">/Year</span></h2>
              </div>

              <div className="pricelandingfirst-section-second">

                {/* <p className="price-landing-prdt-ptd">
                Lorem Ipsum is simply text of the printing and typesetting industry. 
                </p> */}
                <ul className="list-unstyled font-size-5 text-dark-cloud">
                          <li className="mb-6 pricingtnks-nxt">
                            <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                            Adaptive Learning
                          </li>
                          <li className="mb-6 pricingtnks-nxt">
                            <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                            Individual Attension
                          </li>
                          <li className="mb-6 pricingtnks-nxt">
                            <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                            Video tutorials 
                          </li>
                          <li className="mb-6 pricingtnks-nxt">
                            <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                            Mock Test
                          </li>
                          <li className="mb-6 pricingtnks-nxt">
                            <i className="fa fa-check mr-4 text-dodger-blue-to-green" />{" "}
                            Practice Tests
                          </li>
                          <li className="mb-6 pricingtnks-nxt">
                            <i className="fa fa-check mr-4 text-dodger-blue-to-green" />{" "}
                            Doubt Solving
                          </li>
                 </ul>
              <div className="pt-7 pt-lg-5">
                <a className="btn rounded-10  pricing-by-package" href="/#">
                  Subscribe Now
                </a>
              </div>

              </div>


            </div>
          </div>
          {/* End Single Table */}
          {/* Single Table */}
          <div className="col-xl-4 col-lg-5 col-md-6 col-sm-8">
            <div
              className="border rounded-10 text-center pb-13 gr-hover-2 mb-9"
              data-aos="fade-up"
              data-aos-duration={600}
              data-aos-once="true"
            >

              <div className="pricelandingfirst-section-two">
              <p className="price-tp1r mb-5">Self-Paced</p>
              <h2 className="price-fntdsfr mb-1">INR XXX
              <span className="price-landing-mntds mb-2">/month</span></h2>
              <h2 className="price-fntdsfr mb-1">INR XXX 
              <span className="price-landing-mntds mb-2">/Year</span></h2>
              </div>


              <div className="pricelandingfirst-section-second-for-second">

                  {/* <p className="price-landing-prdt-ptd">
                  Lorem Ipsum is simply text of the printing and typesetting industry. 
                  </p> */}
                  <ul className="list-unstyled font-size-5 text-dark-cloud">
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                          Adaptive Learning
                        </li>
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                          Individual Attension
                        </li>
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                          Video Tutorials
                        </li>
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                          Mock Test
                        </li>
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-times mr-4 text-dodger-blue-to-red" />{" "}
                          Practice Tests
                        </li>
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-check mr-4 text-dodger-blue-to-green" />{" "}
                          Doubt Solving
                        </li>
              </ul>
              <div className="pt-7 pt-lg-5">
              <a className="btn rounded-10  pricing-by-package-second" href="/#">
                Subscribe Now
              </a>
              </div>

              </div>
             
              
            </div>
          </div>
          {/* End Single Table */}
          {/* Single Table */}
          <div className="col-xl-4 col-lg-5 col-md-6 col-sm-8">
            <div
              className="border rounded-10 text-center pb-13 gr-hover-2 mb-9"
              data-aos="fade-up"
              data-aos-duration={900}
              data-aos-once="true"
            >
             <div className="pricelandingfirst-section-three">
              <p className="price-tp1r mb-5">Pro</p>
              <h2 className="price-fntdsfr mb-1">INR XXX
              <span className="price-landing-mntds mb-2">/month</span></h2>
              <h2 className="price-fntdsfr mb-1">INR XXX 
              <span className="price-landing-mntds mb-2">/Year</span></h2>
              </div>


              <div className="pricelandingfirst-section-second-for-third">

                  {/* <p className="price-landing-prdt-ptd">
                  Lorem Ipsum is simply text of the printing and typesetting industry. 
                  </p> */}
                  <ul className="list-unstyled font-size-5 text-dark-cloud">
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                          Adaptive Learning
                        </li>
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                          Individual Attension
                        </li>
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                          Video Tutorials
                        </li>
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-times mr-4 text-dodger-blue-to-red" />
                          Mock Test
                        </li>
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-times mr-4 text-dodger-blue-to-red" />{" "}
                          Practice Tests
                        </li>
                        <li className="mb-6 pricingtnks-nxt">
                          <i className="fa fa-check mr-4 text-dodger-blue-to-green" />{" "}
                          Doubt Solving
                        </li>
              </ul>
              <div className="pt-7 pt-lg-5">
              <a className="btn rounded-10  pricing-by-package-third" href="/#">
                Subscribe Now 
              </a>
              </div>

              </div>
            </div>
          </div>
          {/* End Single Table */}
        </div>
      </div>
    </div>

    </div>
  );
};

export default Pricing;
