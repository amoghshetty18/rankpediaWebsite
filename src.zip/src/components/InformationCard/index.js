export { default } from "./InformationCard";
